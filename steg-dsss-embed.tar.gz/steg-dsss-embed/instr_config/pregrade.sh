#!/bin/bash
#
# pregrade.sh - steg-dsss-embed
# Kiem tra cac artifact ma student da sinh ra va ghi flag de checkwork.
#
homedir=$1
destdir=$2
cd "$homedir/$destdir" || exit 0

CHECK_FILE="$homedir/$destdir/check_artifacts.txt"
: > "$CHECK_FILE"

# 1. host.wav - file WAV hop le
if [ -f host.wav ] && file host.wav 2>/dev/null | grep -qi 'WAVE audio'; then
    echo "HOST_OK" >> "$CHECK_FILE"
fi

# 2. message_bits.txt - du 40 bit
if [ -f message_bits.txt ] && [ "$(wc -l < message_bits.txt)" -ge 40 ]; then
    echo "BITS_OK" >> "$CHECK_FILE"
fi

# 3. pn_code.txt - du 8 chip
if [ -f pn_code.txt ] && [ "$(wc -l < pn_code.txt)" -ge 8 ]; then
    echo "PN_OK" >> "$CHECK_FILE"
fi

# 4. chip_sequence.txt - du 320 chip (40 bit * 8 chip)
if [ -f chip_sequence.txt ] && [ "$(wc -l < chip_sequence.txt)" -ge 320 ]; then
    echo "CHIPS_OK" >> "$CHECK_FILE"
fi

# 5. stego.wav - file WAV hop le
if [ -f stego.wav ] && file stego.wav 2>/dev/null | grep -qi 'WAVE audio'; then
    echo "STEGO_OK" >> "$CHECK_FILE"
fi

# 6. Cac file PNG va plots_done.txt
if [ -f plots_done.txt ] && \
   [ -f 01_host_sine.png ] && \
   [ -f 02_pn_sequence.png ] && \
   [ -f 03_message_bits.png ] && \
   [ -f 04_chip_sequence.png ] && \
   [ -f 05_stego_vs_host.png ] && \
   [ -f 06_spectrum.png ]; then
    echo "PLOTS_OK" >> "$CHECK_FILE"
fi
