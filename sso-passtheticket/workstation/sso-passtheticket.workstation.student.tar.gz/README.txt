======================================================================
  BÀI THỰC HÀNH LABTAINER: SSO-PASSTHETICKET (MITRE ATT&CK T1558.001)
  Đánh Cắp Bộ Nhớ Đệm Vé (Pass-the-Ticket) & Phòng Thủ Linux Kernel Keyring
======================================================================
1. Cấu trúc Thực thể:
   - KDC: kdc.lab.lan (172.25.0.10)
   - App Server: app.lab.lan (172.25.0.20) - Cổng Tài chính
   - Workstation: workstation.lab.lan (172.25.0.50) - User: alice, bob

2. Chạy Ma trận Kiểm thử An ninh (5 Test Cases):
   ./run_passtheticket_matrix.sh

3. Đánh giá hoàn thành:
   Sau khi hoàn tất, đóng lab bằng: stoplab
   Chạy lệnh chấm điểm: checkwork sso-passtheticket
======================================================================
