======================================================================
  BÀI THỰC HÀNH LABTAINER: SSO-REPLAY-SKEW (RFC 4120)
  Tấn Công Phát Lại Vé (Replay Attack), Clock Skew & Kerberos Replay Cache
======================================================================
1. Cấu trúc Thực thể:
   - KDC: kdc.lab.lan (172.25.0.10) - Clock Skew Limit: 300s
   - Web Server: web.lab.lan (172.25.0.20) - SPN: HTTP/web.lab.lan
   - Client: client.lab.lan (172.25.0.50) - User: alice

2. Chạy Ma trận Kiểm thử An ninh (5 Test Cases):
   ./run_replayskew_matrix.sh

3. Đánh giá hoàn thành:
   Sau khi hoàn tất, đóng lab bằng: stoplab
   Chạy lệnh chấm điểm: checkwork sso-replay-skew
======================================================================
