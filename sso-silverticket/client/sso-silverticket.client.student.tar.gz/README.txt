======================================================================
  BÀI THỰC HÀNH LABTAINER: SSO-SILVERTICKET (MITRE ATT&CK T1558.002)
  Giả Mạo Vé Dịch Vụ Silver Ticket & Kiểm Soát Rủi Ro Lộ Keytab
======================================================================
1. Cấu trúc Thực thể:
   - KDC: kdc.lab.lan (172.25.0.10)
   - Web Server: web.lab.lan (172.25.0.20) - SPN: HTTP/web.lab.lan
   - Client: client.lab.lan (172.25.0.50) - User: alice

2. Chạy Ma trận Kiểm thử An ninh (5 Test Cases):
   ./run_silverticket_matrix.sh

3. Đánh giá hoàn thành:
   Sau khi hoàn tất, đóng lab bằng: stoplab
   Chạy lệnh chấm điểm: checkwork sso-silverticket
======================================================================
