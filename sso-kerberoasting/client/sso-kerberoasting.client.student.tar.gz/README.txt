======================================================================
  BÀI THỰC HÀNH LABTAINER: SSO-KERBEROASTING (MITRE ATT&CK T1558.003)
  Thám Mã Vé Dịch Vụ TGS-REP Roasting & Khắc Phục Bằng Chuẩn AES-256
======================================================================
1. Cấu trúc Thực thể:
   - KDC: kdc.lab.lan (172.25.0.10)
   - Web Server: web.lab.lan (172.25.0.20) - SPN: HTTP/web.lab.lan
   - Client: client.lab.lan (172.25.0.50) - User: alice

2. Chạy Ma trận Kiểm thử An ninh (5 Test Cases):
   ./run_kerberoast_matrix.sh

3. Đánh giá hoàn thành:
   Sau khi hoàn tất, đóng lab bằng: stoplab
   Chạy lệnh chấm điểm: checkwork sso-kerberoasting
======================================================================
