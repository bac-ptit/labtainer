======================================================================
  BÀI THỰC HÀNH LABTAINER: SSO-PKINIT (RFC 4556)
  Xác thực Passwordless qua Chứng chỉ X.509 & Ma trận 6 Test Cases
======================================================================
1. Cấu trúc thư mục chứng chỉ:
   /home/alice/certs/
     ├── ca_root.crt          (Chứng chỉ Root CA tin cậy)
     ├── alice_valid.crt      (Chứng chỉ PKINIT hợp lệ kèm SAN alice@LAB.LAN)
     ├── alice_valid.key      (Khóa bí mật tương ứng)
     ├── alice_untrusted.crt  (Chứng chỉ cấp bởi Rogue CA không tin cậy)
     ├── bob_mismatch.crt     (Chứng chỉ hợp lệ nhưng SAN bob@LAB.LAN)
     └── alice_revoked.crt    (Chứng chỉ đã bị CA thu hồi trong CRL)

2. Chạy Ma trận Kiểm thử An ninh (6 Test Cases):
   ./run_pkinit_matrix.sh

3. Đánh giá hoàn thành:
   Sau khi hoàn tất, đóng lab bằng: stoplab
   Chạy lệnh chấm điểm: checkwork sso-pkinit
======================================================================
