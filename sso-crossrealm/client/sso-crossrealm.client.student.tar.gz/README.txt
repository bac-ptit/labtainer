======================================================================
  BÀI THỰC HÀNH LABTAINER: SSO-CROSSREALM (RFC 4120)
  Đăng Nhập Một Lần Liên Miền & Kiểm Soát Ranh Giới Tin Cậy
======================================================================
1. Cấu trúc Liên minh Kerberos (Consortium Realms):
   - Nguồn: STUDENT.LAB (KDC: 172.25.0.10) - Người dùng: alice, charlie
   - Đích:  RESEARCH.LAB (KDC: 172.25.0.20) - Ứng dụng: app.research.lab
   - Khóa chia sẻ tin cậy: krbtgt/RESEARCH.LAB@STUDENT.LAB (AES-256)

2. Chạy Ma trận Kiểm thử An ninh (5 Test Cases):
   ./run_crossrealm_matrix.sh

3. Đánh giá hoàn thành:
   Sau khi hoàn tất, đóng lab bằng: stoplab
   Chạy lệnh chấm điểm: checkwork sso-crossrealm
======================================================================
